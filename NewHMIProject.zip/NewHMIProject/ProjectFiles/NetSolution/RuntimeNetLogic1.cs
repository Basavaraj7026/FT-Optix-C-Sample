#region Using directives
using System;
using UAManagedCore;
using OpcUa = UAManagedCore.OpcUa;
using FTOptix.UI;
using FTOptix.NativeUI;
using FTOptix.HMIProject;
using FTOptix.Retentivity;
using FTOptix.CoreBase;
using FTOptix.Core;
using FTOptix.NetLogic;
using FTOptix.RAEtherNetIP;
using FTOptix.CommunicationDriver;
#endregion

public class RuntimeNetLogic1 : BaseNetLogic
{
    public override void Start()
    {
        // Insert code to be executed when the user-defined logic is started
    }

    public override void Stop()
    {
        // Insert code to be executed when the user-defined logic is stopped
    }

    [ExportMethod]

public void Add(){
var Fno = (float)Project.Current.GetVariable("Model/Fno").Value;
var Sno = (float)Project.Current.GetVariable("Model/Sno").Value;
Project.Current.GetVariable("Model/Rno").Value = Fno + Sno;

} 
public void Sub(){
var Fno = (float)Project.Current.GetVariable("Model/Fno").Value;
var Sno = (float)Project.Current.GetVariable("Model/Sno").Value;
Project.Current.GetVariable("Model/Rno").Value = Fno - Sno;
} 

public void Mul(){
var Fno = (float)Project.Current.GetVariable("Model/Fno").Value;
var Sno = (float)Project.Current.GetVariable("Model/Sno").Value;
Project.Current.GetVariable("Model/Rno").Value = Fno * Sno;
} 

public void Div(){
var Fno = (float)Project.Current.GetVariable("Model/Fno").Value;
var Sno = (float)Project.Current.GetVariable("Model/Sno").Value;
Project.Current.GetVariable("Model/Rno").Value = Fno / Sno;
} 

}

