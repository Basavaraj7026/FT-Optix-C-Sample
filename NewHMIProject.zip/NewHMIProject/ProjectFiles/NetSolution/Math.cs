#region Using directives
using System;
using UAManagedCore;
using OpcUa = UAManagedCore.OpcUa;
using FTOptix.UI;
using FTOptix.NativeUI;
using FTOptix.HMIProject;
using FTOptix.Retentivity;
using FTOptix.CoreBase;
using FTOptix.Core;
using FTOptix.NetLogic;
using FTOptix.RAEtherNetIP;
using System.Threading;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Security.Cryptography.X509Certificates;
using FTOptix.CommunicationDriver;
#endregion

public class Math : BaseNetLogic
{
   Exception ex;
    [ExportMethod]
    public static void Operation()
    {
        float Method = (int)Project.Current.GetVariable("Model/Method").Value;
        float Fno = (float)Project.Current.GetVariable("Model/Fno").Value;
        float Sno = (float)Project.Current.GetVariable("Model/Sno").Value;
        switch (Method)
        {
            case 0:
                Project.Current.GetVariable("Model/Rno").Value = "Result For Addtion is : " + (Fno + Sno);
                break;
            case 1:
                Project.Current.GetVariable("Model/Rno").Value = "Result For Subtraction is : " + (Fno - Sno);
                break;
            case 2:
                Project.Current.GetVariable("Model/Rno").Value = "Result For Multiplication is : " + (Fno * Sno);
                break;
            case 3:
                Project.Current.GetVariable("Model/Rno").Value = "Result For Division is : " + (Fno / Sno);
                break;
        }
       
    }
    [ExportMethod]
    public static void Main2()
    {
       
        float Fno = (float)Project.Current.GetVariable("Model/Fno").Value;
        float Sno = (float)Project.Current.GetVariable("Model/Sno").Value;

        for (float i = Fno; i <= Sno; i++)
        {
            //Project.Current.GetVariable("Model/Rno").Value = "Result For Addtion is : " +   i;
            Log.Error("No"+i.ToString());
        }
    }
}


