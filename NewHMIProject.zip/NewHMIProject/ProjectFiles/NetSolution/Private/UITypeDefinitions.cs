using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "NewHMIProject", Guid = "01a7e8933afd7c95fe894b0859308138")]
public class MainWindow : FTOptix.UI.Window
{
}
