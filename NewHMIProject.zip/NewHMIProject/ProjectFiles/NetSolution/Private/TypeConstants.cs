using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace NewHMIProject
{
    public static class ObjectTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("NewHMIProject");
        public static readonly NodeId MainWindow = new NodeId(namespaceIndex, new Guid("01a7e8933afd7c95fe894b0859308138"));
    }

    public static class VariableTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("NewHMIProject");
    }
}
